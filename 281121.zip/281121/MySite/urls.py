from django.contrib import admin
from django.urls import path, include
from django.urls.conf import include

import library.views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('library.urls')),
    path('api/', include('library.urls')),
]
