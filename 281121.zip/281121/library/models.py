from django.db import models
from django.db.models.deletion import CASCADE

# Create your models here.


class Author(models.Model):
    name = models.CharField('Name', max_length=256)
    date_of_birth = models.DateField('Date of Birth', auto_now=False)

    def __str__(self):
        return self.name


class Book(models.Model):
    title = models.CharField('Title', max_length=256)
    genre = models.CharField('Genre', max_length=256)
    date_of_publishing = models.DateField('Date of Publishing', auto_now=False)
    author = models.ForeignKey(Author, on_delete=CASCADE)

    def __str__(self):
        return self.title
    

