from django.urls import path
from . import views

urlpatterns = [
    path('', views.My_Books, name='My_Books'),
    path('api/', views.libraryOverview, name='library-overview'),
    path('author-list/', views.authorList, name='author-list'),
    path('author-detail/<str:pk>/', views.authorDetail, name='author-detail'),
    path('author-create/', views.authorCreate, name='author-create'),
    path('author-update/<str:pk>/', views.authorUpdate, name='author-update'),
    path('author-delete/<str:pk>/', views.authorDelete, name='author-delete'),
]
