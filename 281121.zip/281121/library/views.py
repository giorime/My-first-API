from django.http import request
from django.http.response import JsonResponse
from django.shortcuts import render
from .models import Author, Book

from django.http import JsonResponse

from rest_framework.decorators import api_view
from rest_framework.response import Response
from .serializers import AuthorSerializer


from .models import Author
# Create your views here.

def My_Books(request):

    return render(request, 'library/index.html')

@api_view(['GET'])
def libraryOverview(request):
    api_urls = {
        'List':'/author-list',
        'Detail View':'author/-detail/<str:pk>/',
        'Create':'/author-create/',
        'Update':'/author-update/<str:pk>/',
        'Delete':'/author-delete/<str:pk>/',
    }

    return Response(api_urls)

@api_view(['GET'])
def authorList(request):
    author = Author.objects.all()
    serializer = AuthorSerializer(author, many=True)
    return Response(serializer.data)



@api_view(['GET'])
def authorDetail(request, pk):
    author = Author.objects.get(id=pk)
    serializer = AuthorSerializer(author, many=False)
    return Response(serializer.data)


@api_view(['POST'])
def authorCreate(request):
    serializer = AuthorSerializer(data=request.data)

    if serializer.is_valid():
        serializer.save()

    return Response(serializer.data)


@api_view(['POST'])
def authorUpdate(request, pk):
    author = Author.objects.get(id=pk)
    serializer = AuthorSerializer(instance=author, data=request.data)

    if serializer.is_valid():
        serializer.save()

    return Response(serializer.data)


@api_view(['DELETE'])
def authorDelete(request, pk):
    author = Author.objects.get(id=pk)
    author.delete()

    return Response('Author deleted')    